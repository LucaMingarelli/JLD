
def a_complicated_function():
    print("Working... Done.")
