def function2():
    print("Working... Done.")
