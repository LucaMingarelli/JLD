from .module2 import function2
